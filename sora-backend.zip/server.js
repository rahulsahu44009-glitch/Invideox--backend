import express from "express";
import cors from "cors";
import { OpenAI } from "openai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

app.post("/generate-video", async (req, res) => {
  try {
    const { prompt } = req.body;

    const response = await client.videos.generate({
      model: "gpt-4.1-mini",
      prompt: prompt,
      size: "1920x1080",
      duration: "5s",
      format: "mp4"
    });

    const videoUrl = response.data.url;

    res.json({ videoUrl });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Video generation error" });
  }
});

app.get("/", (req, res) => {
  res.send("Sora backend running...");
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
